# NEURO CLOCK Android

Проект собирается через GitHub Actions (см. .github/workflows/build-apk.yml в корне репозитория).
Интерфейс лежит в app/src/main/assets/index.html, шрифты в app/src/main/assets/fonts, оболочка Android в MainActivity.kt.
