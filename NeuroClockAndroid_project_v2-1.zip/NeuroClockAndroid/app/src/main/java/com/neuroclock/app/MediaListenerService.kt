package com.neuroclock.app

import android.service.notification.NotificationListenerService

// Пустая служба: нужна только для того, чтобы Android разрешил приложению читать активные медиасессии.
class MediaListenerService : NotificationListenerService()
