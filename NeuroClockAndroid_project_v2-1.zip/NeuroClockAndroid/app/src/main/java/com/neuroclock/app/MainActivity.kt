package com.neuroclock.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.SearchManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.KeyEvent
import android.view.WindowInsets
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private var web: WebView? = null
    private var safeTop = 0f
    private var safeBottom = 0f
    private var filePathCb: ValueCallback<Array<Uri>>? = null
    private val handler = Handler(Looper.getMainLooper())

    private fun pushInsets() {
        val w = web ?: return
        val js = "document.documentElement.style.setProperty('--safe-top','" + safeTop +
            "px');document.documentElement.style.setProperty('--safe-bottom','" + safeBottom + "px');"
        w.evaluateJavascript(js, null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun requestLocation() {
            runOnUiThread { startLocation() }
        }

        @JavascriptInterface
        fun httpGet(url: String, id: Int, timeoutMs: Int) {
            Thread {
                var code = 0
                var body = ""
                try {
                    val conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = timeoutMs
                    conn.readTimeout = timeoutMs
                    conn.setRequestProperty("User-Agent", "NeuroClock/1.0 (Android; personal clock app)")
                    conn.setRequestProperty("Accept", "application/json")
                    code = conn.responseCode
                    val stream = if (code in 200..399) conn.inputStream else conn.errorStream
                    body = stream?.bufferedReader()?.use { it.readText() } ?: ""
                    conn.disconnect()
                } catch (e: Exception) {
                    code = 0
                    body = ""
                }
                val js = "window.onNativeHttp&&window.onNativeHttp(" + id + "," + code + "," + JSONObject.quote(body) + ")"
                runOnUiThread { web?.evaluateJavascript(js, null) }
            }.start()
        }

        @JavascriptInterface
        fun mediaState(): String = buildMediaState()

        @JavascriptInterface
        fun mediaArt(): String = buildMediaArt()

        @JavascriptInterface
        fun mediaPlayPause() {
            runOnUiThread { mediaControl(0) }
        }

        @JavascriptInterface
        fun mediaNext() {
            runOnUiThread { mediaControl(1) }
        }

        @JavascriptInterface
        fun mediaPrev() {
            runOnUiThread { mediaControl(2) }
        }

        @JavascriptInterface
        fun mediaSeek(ms: Double) {
            runOnUiThread { activeController()?.transportControls?.seekTo(ms.toLong()) }
        }

        @JavascriptInterface
        fun mediaOpenSettings() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun openAppSettings() {
            runOnUiThread {
                try {
                    val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    i.data = Uri.parse("package:" + packageName)
                    startActivity(i)
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun launchApp(pkg: String) {
            runOnUiThread { launchPackage(pkg) }
        }

        @JavascriptInterface
        fun playFromSearch(pkg: String, query: String) {
            runOnUiThread {
                try {
                    val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                    i.putExtra(SearchManager.QUERY, query)
                    i.putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/audio")
                    if (pkg.isNotEmpty()) i.setPackage(pkg)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } catch (e: Exception) {
                    launchPackage(pkg)
                }
            }
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread {
                try {
                    if (url.startsWith("https://")) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun sendLoc(l: Location) {
        web?.evaluateJavascript(
            "window.onNativeLocation&&window.onNativeLocation(" + l.latitude + "," + l.longitude + ")", null
        )
    }

    private fun sendLocError(code: String) {
        web?.evaluateJavascript("window.onNativeLocationError&&window.onNativeLocationError('" + code + "')", null)
    }

    private fun hasLocationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < 23) return true
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun startLocation() {
        if (!hasLocationPermission()) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                31
            )
            return
        }
        fetchLocation()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 31) {
            var ok = false
            for (g in grantResults) {
                if (g == PackageManager.PERMISSION_GRANTED) ok = true
            }
            if (ok) fetchLocation() else sendLocError("denied")
        }
    }

    @SuppressLint("MissingPermission")
    private fun fetchLocation() {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = lm.getProviders(true)
        if (providers.isEmpty()) {
            sendLocError("disabled")
            return
        }
        var best: Location? = null
        for (prov in providers) {
            val l: Location? = try {
                lm.getLastKnownLocation(prov)
            } catch (e: Exception) {
                null
            }
            if (l != null) {
                val b = best
                if (b == null || l.accuracy < b.accuracy) best = l
            }
        }
        val found = best
        if (found != null) {
            sendLoc(found)
            return
        }
        val prov = if (providers.contains(LocationManager.NETWORK_PROVIDER)) LocationManager.NETWORK_PROVIDER else providers[0]
        var done = false
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (!done) {
                    done = true
                    lm.removeUpdates(this)
                    sendLoc(location)
                }
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        try {
            lm.requestLocationUpdates(prov, 0L, 0f, listener, Looper.getMainLooper())
        } catch (e: Exception) {
            sendLocError("disabled")
            return
        }
        handler.postDelayed({
            if (!done) {
                done = true
                lm.removeUpdates(listener)
                sendLocError("timeout")
            }
        }, 15000)
    }


    private fun launchPackage(pkg: String) {
        try {
            if (pkg.isEmpty()) return
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
        } catch (e: Exception) {
        }
    }

    private var cbController: MediaController? = null
    private val mediaCb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            notifyMedia()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            notifyMedia()
        }

        override fun onSessionDestroyed() {
            notifyMedia()
        }
    }

    private fun notifyMedia() {
        web?.evaluateJavascript("window.onNativeMedia&&window.onNativeMedia()", null)
    }

    private fun attachMediaCb(c: MediaController?) {
        if (c === cbController) return
        try {
            cbController?.unregisterCallback(mediaCb)
        } catch (e: Exception) {
        }
        cbController = c
        if (c != null) {
            try {
                c.registerCallback(mediaCb, handler)
            } catch (e: Exception) {
            }
        }
    }

    private fun hasMediaAccess(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        for (s in flat.split(":")) {
            val cn = ComponentName.unflattenFromString(s)
            if (cn != null && cn.packageName == packageName) return true
        }
        return false
    }

    private fun activeController(): MediaController? {
        if (!hasMediaAccess()) return null
        return try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(this, MediaListenerService::class.java))
            var pick: MediaController? = null
            for (c in list) {
                if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
                    pick = c
                    break
                }
            }
            if (pick != null) pick else if (list.isNotEmpty()) list[0] else null
        } catch (e: Exception) {
            null
        }
    }

    private fun buildMediaState(): String {
        val o = JSONObject()
        o.put("access", hasMediaAccess())
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        o.put("active", am.isMusicActive)
        val c = activeController()
        attachMediaCb(c)
        if (c == null) {
            o.put("has", false)
            return o.toString()
        }
        val md = c.metadata
        val st = c.playbackState
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val dur = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val playing = st != null && st.state == PlaybackState.STATE_PLAYING
        var pos = st?.position ?: 0L
        val speed = st?.playbackSpeed ?: 1f
        if (st != null && playing) pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * speed).toLong()
        if (dur > 0 && pos > dur) pos = dur
        if (pos < 0) pos = 0
        o.put("has", title.isNotEmpty() || artist.isNotEmpty())
        o.put("title", title)
        o.put("artist", artist)
        o.put("dur", dur)
        o.put("pos", pos)
        o.put("speed", speed.toDouble())
        o.put("playing", playing)
        o.put("pkg", c.packageName)
        var label = ""
        try {
            label = packageManager.getApplicationLabel(packageManager.getApplicationInfo(c.packageName, 0)).toString()
        } catch (e: Exception) {
        }
        o.put("app", label)
        o.put("artId", title + "|" + artist + "|" + dur + "|" + c.packageName)
        return o.toString()
    }

    private fun buildMediaArt(): String {
        val c = activeController() ?: return ""
        val md = c.metadata ?: return ""
        var bmp: Bitmap? = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
        if (bmp == null) bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ART)
        if (bmp == null) bmp = md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (bmp == null) {
            val uriStr = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                ?: md.getString(MediaMetadata.METADATA_KEY_ART_URI)
                ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
            if (uriStr != null) {
                try {
                    val u = Uri.parse(uriStr)
                    val sch = u.scheme
                    if (sch == "content" || sch == "file" || sch == "android.resource") {
                        val ins = contentResolver.openInputStream(u)
                        if (ins != null) {
                            bmp = BitmapFactory.decodeStream(ins)
                            ins.close()
                        }
                    } else if (sch == "http" || sch == "https") {
                        val conn = URL(uriStr).openConnection() as HttpURLConnection
                        conn.connectTimeout = 4000
                        conn.readTimeout = 4000
                        bmp = BitmapFactory.decodeStream(conn.inputStream)
                        conn.disconnect()
                    }
                } catch (e: Exception) {
                }
            }
        }
        val b = bmp ?: return ""
        val sc = Math.min(1f, 640f / Math.max(b.width, b.height).toFloat())
        val out = if (sc < 1f) Bitmap.createScaledBitmap(b, (b.width * sc).toInt(), (b.height * sc).toInt(), true) else b
        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 86, bos)
        return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    private fun sendMediaKey(code: Int) {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        } catch (e: Exception) {
        }
    }

    private fun mediaControl(kind: Int) {
        val c = activeController()
        if (c == null) {
            if (kind == 0) sendMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            else if (kind == 1) sendMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
            else sendMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            return
        }
        val tc = c.transportControls
        if (kind == 0) {
            if (c.playbackState?.state == PlaybackState.STATE_PLAYING) tc.pause() else tc.play()
        } else if (kind == 1) {
            tc.skipToNext()
        } else {
            tc.skipToPrevious()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(5, 5, 5)))
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        val view = WebView(this)
        web = view
        view.setBackgroundColor(Color.rgb(5, 5, 5))
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.cacheMode = WebSettings.LOAD_DEFAULT
        view.settings.mediaPlaybackRequiresUserGesture = false
        view.addJavascriptInterface(Bridge(), "AndroidBridge")
        view.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) {
                pushInsets()
            }
        }
        view.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                filePathCb?.onReceiveValue(null)
                filePathCb = filePathCallback
                return try {
                    startActivityForResult(fileChooserParams!!.createIntent(), 21)
                    true
                } catch (e: Exception) {
                    filePathCb = null
                    false
                }
            }
        }
        view.setOnApplyWindowInsetsListener { v, insets ->
            val density = v.resources.displayMetrics.density
            var top = 0
            var bottom = 0
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                val ime = insets.getInsets(WindowInsets.Type.ime())
                top = bars.top
                bottom = Math.max(bars.bottom, ime.bottom)
            } else {
                top = insets.systemWindowInsetTop
                bottom = insets.systemWindowInsetBottom
            }
            safeTop = top / density
            safeBottom = bottom / density
            pushInsets()
            insets
        }
        view.loadUrl("file:///android_asset/index.html")
        setContentView(view)
        view.requestApplyInsets()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 21) {
            filePathCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            filePathCb = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onBackPressed() {
        val w = web
        if (w == null) {
            finish()
            return
        }
        w.evaluateJavascript("(window.nativeBack?window.nativeBack():false)") { r ->
            if (r != "true") finish()
        }
    }
}
