package com.neuroclock.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.SearchManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.browse.MediaBrowser
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.util.Base64
import android.view.KeyEvent
import android.view.WindowInsets
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class MainActivity : Activity() {
    private var web: WebView? = null
    private var safeTop = 0f
    private var safeBottom = 0f
    private var filePathCb: ValueCallback<Array<Uri>>? = null
    private val handler = Handler(Looper.getMainLooper())

    private fun pushInsets() {
        val w = web ?: return
        val js = "document.documentElement.style.setProperty('--safe-top','" + safeTop +
            "px');document.documentElement.style.setProperty('--safe-bottom','" + safeBottom + "px');"
        w.evaluateJavascript(js, null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun requestLocation() {
            runOnUiThread { startLocation() }
        }

        @JavascriptInterface
        fun httpGet(url: String, id: Int, timeoutMs: Int) {
            Thread {
                var code = 0
                var body = ""
                try {
                    val conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = timeoutMs
                    conn.readTimeout = timeoutMs
                    conn.setRequestProperty("User-Agent", "NeuroClock/1.0 (Android; personal clock app)")
                    conn.setRequestProperty("Accept", "application/json")
                    code = conn.responseCode
                    val stream = if (code in 200..399) conn.inputStream else conn.errorStream
                    body = stream?.bufferedReader()?.use { it.readText() } ?: ""
                    conn.disconnect()
                } catch (e: Exception) {
                    code = 0
                    body = ""
                }
                val js = "window.onNativeHttp&&window.onNativeHttp(" + id + "," + code + "," + JSONObject.quote(body) + ")"
                runOnUiThread { web?.evaluateJavascript(js, null) }
            }.start()
        }

        @JavascriptInterface
        fun mediaState(): String = buildMediaState()

        @JavascriptInterface
        fun mediaArt(): String = buildMediaArt()

        @JavascriptInterface
        fun mediaPlayPause() {
            runOnUiThread { mediaControl(0) }
        }

        @JavascriptInterface
        fun mediaNext() {
            runOnUiThread { mediaControl(1) }
        }

        @JavascriptInterface
        fun mediaPrev() {
            runOnUiThread { mediaControl(2) }
        }

        @JavascriptInterface
        fun mediaSeek(ms: Double) {
            runOnUiThread { activeController()?.transportControls?.seekTo(ms.toLong()) }
        }

        @JavascriptInterface
        fun mediaOpenSettings() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun mediaOpenListenerDetail(): Boolean {
            runOnUiThread {
                try {
                    if (Build.VERSION.SDK_INT >= 30) {
                        val i = Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
                        i.putExtra(
                            Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                            ComponentName(this@MainActivity, MediaListenerService::class.java).flattenToString()
                        )
                        startActivity(i)
                    } else {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }
                } catch (e: Exception) {
                    try {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    } catch (e2: Exception) {
                    }
                }
            }
            return true
        }

        @JavascriptInterface
        fun mediaAutoEnable(): Boolean = autoEnableMediaAccess()

        @JavascriptInterface
        fun openAppSettings() {
            runOnUiThread {
                try {
                    val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    i.data = Uri.parse("package:" + packageName)
                    startActivity(i)
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun launchApp(pkg: String) {
            runOnUiThread { launchPackage(pkg) }
        }

        @JavascriptInterface
        fun playFromSearch(pkg: String, query: String) {
            runOnUiThread { playTrackSmart(pkg, query, "") }
        }

        @JavascriptInterface
        fun playTrack(pkg: String, query: String, mid: String) {
            runOnUiThread { playTrackSmart(pkg, query, mid) }
        }

        @JavascriptInterface
        fun deviceState(): String = buildDeviceState()

        @JavascriptInterface
        fun fetchLyrics(key: String, artist: String, title: String, durSec: Int) {
            fetchLyricsAsync(key, artist, title, durSec)
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread {
                try {
                    if (url.startsWith("https://")) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun sendLoc(l: Location) {
        web?.evaluateJavascript(
            "window.onNativeLocation&&window.onNativeLocation(" + l.latitude + "," + l.longitude + ")", null
        )
    }

    private fun sendLocError(code: String) {
        web?.evaluateJavascript("window.onNativeLocationError&&window.onNativeLocationError('" + code + "')", null)
    }

    private fun hasLocationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < 23) return true
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun startLocation() {
        if (!hasLocationPermission()) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                31
            )
            return
        }
        fetchLocation()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 31) {
            var ok = false
            for (g in grantResults) {
                if (g == PackageManager.PERMISSION_GRANTED) ok = true
            }
            if (ok) fetchLocation() else sendLocError("denied")
        }
    }

    @SuppressLint("MissingPermission")
    private fun fetchLocation() {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = lm.getProviders(true)
        if (providers.isEmpty()) {
            sendLocError("disabled")
            return
        }
        var best: Location? = null
        for (prov in providers) {
            val l: Location? = try {
                lm.getLastKnownLocation(prov)
            } catch (e: Exception) {
                null
            }
            if (l != null) {
                val b = best
                if (b == null || l.accuracy < b.accuracy) best = l
            }
        }
        val found = best
        if (found != null) {
            sendLoc(found)
            return
        }
        val prov = if (providers.contains(LocationManager.NETWORK_PROVIDER)) LocationManager.NETWORK_PROVIDER else providers[0]
        var done = false
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (!done) {
                    done = true
                    lm.removeUpdates(this)
                    sendLoc(location)
                }
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        try {
            lm.requestLocationUpdates(prov, 0L, 0f, listener, Looper.getMainLooper())
        } catch (e: Exception) {
            sendLocError("disabled")
            return
        }
        handler.postDelayed({
            if (!done) {
                done = true
                lm.removeUpdates(listener)
                sendLocError("timeout")
            }
        }, 15000)
    }


    private fun launchPackage(pkg: String) {
        try {
            if (pkg.isEmpty()) return
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
        } catch (e: Exception) {
        }
    }

    private var cbController: MediaController? = null
    private val mediaCb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            notifyMedia()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            notifyMedia()
        }

        override fun onSessionDestroyed() {
            notifyMedia()
        }
    }

    private fun notifyMedia() {
        web?.evaluateJavascript("window.onNativeMedia&&window.onNativeMedia()", null)
    }

    private fun attachMediaCb(c: MediaController?) {
        if (c === cbController) return
        try {
            cbController?.unregisterCallback(mediaCb)
        } catch (e: Exception) {
        }
        cbController = c
        if (c != null) {
            try {
                c.registerCallback(mediaCb, handler)
            } catch (e: Exception) {
            }
        }
    }

    private fun hasMediaAccess(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        for (s in flat.split(":")) {
            val cn = ComponentName.unflattenFromString(s)
            if (cn != null && cn.packageName == packageName) return true
        }
        return false
    }

    private fun canWriteSecure(): Boolean =
        checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    // Если выдано разрешение WRITE_SECURE_SETTINGS (одна команда adb), включаем доступ к уведомлениям сами
    private fun autoEnableMediaAccess(): Boolean {
        if (hasMediaAccess()) return true
        if (!canWriteSecure()) return false
        return try {
            val cn = ComponentName(this, MediaListenerService::class.java).flattenToString()
            val cur = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
            val list = if (cur.isEmpty()) cn else "$cur:$cn"
            Settings.Secure.putString(contentResolver, "enabled_notification_listeners", list)
            hasMediaAccess()
        } catch (e: Exception) {
            false
        }
    }

    private fun rebindListener() {
        if (Build.VERSION.SDK_INT >= 24 && hasMediaAccess()) {
            try {
                NotificationListenerService.requestRebind(ComponentName(this, MediaListenerService::class.java))
            } catch (e: Exception) {
            }
        }
    }

    override fun onResume() {
        super.onResume()
        autoEnableMediaAccess()
        rebindListener()
        web?.evaluateJavascript("window.onNativeMedia&&window.onNativeMedia()", null)
    }

    private fun activeController(): MediaController? {
        if (!hasMediaAccess()) return null
        return try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(this, MediaListenerService::class.java))
            var pick: MediaController? = null
            for (c in list) {
                if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
                    pick = c
                    break
                }
            }
            if (pick != null) pick else if (list.isNotEmpty()) list[0] else null
        } catch (e: Exception) {
            null
        }
    }

    private fun buildMediaState(): String {
        val o = JSONObject()
        o.put("access", hasMediaAccess())
        o.put("canAuto", canWriteSecure())
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        o.put("active", am.isMusicActive)
        val c = activeController()
        attachMediaCb(c)
        if (c == null) {
            o.put("has", false)
            return o.toString()
        }
        val md = c.metadata
        val st = c.playbackState
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val dur = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val playing = st != null && st.state == PlaybackState.STATE_PLAYING
        var pos = st?.position ?: 0L
        val speed = st?.playbackSpeed ?: 1f
        if (st != null && playing) pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * speed).toLong()
        if (dur > 0 && pos > dur) pos = dur
        if (pos < 0) pos = 0
        o.put("has", title.isNotEmpty() || artist.isNotEmpty())
        o.put("title", title)
        o.put("artist", artist)
        o.put("dur", dur)
        o.put("pos", pos)
        o.put("speed", speed.toDouble())
        o.put("playing", playing)
        o.put("pkg", c.packageName)
        var label = ""
        try {
            label = packageManager.getApplicationLabel(packageManager.getApplicationInfo(c.packageName, 0)).toString()
        } catch (e: Exception) {
        }
        o.put("app", label)
        o.put("artId", title + "|" + artist + "|" + dur + "|" + c.packageName)
        val mdd = c.metadata
        o.put("mid", mdd?.description?.mediaId ?: mdd?.getString(MediaMetadata.METADATA_KEY_MEDIA_ID) ?: "")
        return o.toString()
    }

    private var artCacheKey = ""
    private var artCacheVal = ""
    private val artFetching = HashSet<String>()

    private fun encodeArt(b: Bitmap): String {
        val sc = Math.min(1f, 640f / Math.max(b.width, b.height).toFloat())
        val out = if (sc < 1f) Bitmap.createScaledBitmap(b, (b.width * sc).toInt(), (b.height * sc).toInt(), true) else b
        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 86, bos)
        return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    private fun fetchArtAsync(key: String, uriStr: String) {
        synchronized(artFetching) {
            if (artFetching.contains(key)) return
            artFetching.add(key)
        }
        Thread {
            try {
                val conn = URL(uriStr).openConnection() as HttpURLConnection
                conn.connectTimeout = 6000
                conn.readTimeout = 8000
                val bmp = BitmapFactory.decodeStream(conn.inputStream)
                conn.disconnect()
                if (bmp != null) {
                    val enc = encodeArt(bmp)
                    artCacheKey = key
                    artCacheVal = enc
                    runOnUiThread { web?.evaluateJavascript("window.onNativeArt&&window.onNativeArt()", null) }
                }
            } catch (e: Exception) {
            }
            synchronized(artFetching) { artFetching.remove(key) }
        }.start()
    }

    private fun buildMediaArt(): String {
        val c = activeController() ?: return ""
        val md = c.metadata ?: return ""
        val key = (md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "") + "|" +
            (md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "") + "|" + c.packageName
        if (key == artCacheKey && artCacheVal.isNotEmpty()) return artCacheVal
        var bmp: Bitmap? = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
        if (bmp == null) bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ART)
        if (bmp == null) bmp = md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (bmp == null) {
            val uriStr = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                ?: md.getString(MediaMetadata.METADATA_KEY_ART_URI)
                ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
            if (uriStr != null) {
                try {
                    val sch = Uri.parse(uriStr).scheme
                    if (sch == "content" || sch == "file" || sch == "android.resource") {
                        val ins = contentResolver.openInputStream(Uri.parse(uriStr))
                        if (ins != null) {
                            bmp = BitmapFactory.decodeStream(ins)
                            ins.close()
                        }
                    } else if (sch == "http" || sch == "https") {
                        fetchArtAsync(key, uriStr)
                    }
                } catch (e: Exception) {
                }
            }
        }
        val b = bmp ?: return ""
        val enc = encodeArt(b)
        artCacheKey = key
        artCacheVal = enc
        return enc
    }

    private fun sessionFor(pkg: String): MediaController? {
        if (pkg.isEmpty() || !hasMediaAccess()) return null
        return try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            msm.getActiveSessions(ComponentName(this, MediaListenerService::class.java)).firstOrNull { it.packageName == pkg }
        } catch (e: Exception) {
            null
        }
    }

    private fun musicPlaying(): Boolean {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.isMusicActive
    }

    private fun launchSearchIntent(pkg: String, query: String) {
        try {
            val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            i.putExtra(SearchManager.QUERY, query)
            i.putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            i.putExtra(MediaStore.EXTRA_MEDIA_TITLE, query)
            if (pkg.isNotEmpty()) i.setPackage(pkg)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            launchPackage(pkg)
        }
    }

    private fun forcePlay(pkg: String) {
        if (musicPlaying()) return
        val c = sessionFor(pkg) ?: activeController()
        if (c != null) {
            try {
                c.transportControls.play()
            } catch (e: Exception) {
            }
        } else {
            sendMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
        }
    }

    private fun titleMatches(c: MediaController?, query: String): Boolean {
        val t = c?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)?.trim()?.lowercase() ?: return false
        return t.isNotEmpty() && query.lowercase().contains(t)
    }

    private fun playingTarget(pkg: String, query: String): Boolean {
        val c = sessionFor(pkg) ?: return false
        return titleMatches(c, query) && c.playbackState?.state == PlaybackState.STATE_PLAYING
    }

    private fun sendToController(c: MediaController, query: String, mid: String) {
        try {
            val b = Bundle()
            b.putString(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            if (mid.isNotEmpty()) c.transportControls.playFromMediaId(mid, null)
            else c.transportControls.playFromSearch(query, b)
        } catch (e: Exception) {
        }
    }

    // Подключаемся к музыкальному сервису приложения напрямую (как Android Auto), даже если оно закрыто
    private fun playViaBrowser(pkg: String, query: String, mid: String) {
        try {
            val svc = packageManager.queryIntentServices(
                Intent("android.media.browse.MediaBrowserService").setPackage(pkg), 0
            ).firstOrNull()?.serviceInfo ?: return
            var browser: MediaBrowser? = null
            browser = MediaBrowser(this, ComponentName(svc.packageName, svc.name), object : MediaBrowser.ConnectionCallback() {
                override fun onConnected() {
                    try {
                        val tok = browser?.sessionToken
                        if (tok != null) sendToController(MediaController(this@MainActivity, tok), query, mid)
                    } catch (e: Exception) {
                    }
                    Handler(Looper.getMainLooper()).postDelayed({
                        try {
                            browser?.disconnect()
                        } catch (e: Exception) {
                        }
                    }, 8000)
                }
            }, null)
            browser?.connect()
        } catch (e: Exception) {
        }
    }

    // Включаем именно этот трек: сессия плеера, затем прямое подключение к сервису, и только потом открытие приложения
    private fun playTrackSmart(pkg: String, query: String, mid: String) {
        val h = Handler(Looper.getMainLooper())
        val sc = sessionFor(pkg)
        if (sc != null) sendToController(sc, query, mid) else playViaBrowser(pkg, query, mid)
        h.postDelayed({
            if (!playingTarget(pkg, query)) {
                if (sc != null) playViaBrowser(pkg, query, "")
            }
        }, 2500)
        h.postDelayed({ if (!playingTarget(pkg, query)) launchSearchIntent(pkg, query) }, 5500)
        h.postDelayed({
            val c = sessionFor(pkg)
            if (c != null && titleMatches(c, query) && c.playbackState?.state != PlaybackState.STATE_PLAYING) {
                try {
                    c.transportControls.play()
                } catch (e: Exception) {
                }
            } else if (!musicPlaying()) {
                forcePlay(pkg)
            }
        }, 10000)
    }

    private fun jstr(o: JSONObject, k: String): String = if (o.isNull(k)) "" else o.optString(k, "")

    private fun httpGetText(u: String): String? {
        return try {
            val conn = URL(u).openConnection() as HttpURLConnection
            conn.connectTimeout = 7000
            conn.readTimeout = 9000
            conn.setRequestProperty("User-Agent", "NeuroClock/1.0 (Android)")
            if (conn.responseCode != 200) {
                conn.disconnect()
                null
            } else {
                val t = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                conn.disconnect()
                t
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun cleanTitle(t: String): String =
        t.replace(Regex("\\(.*?\\)|\\[.*?\\]"), "").replace(Regex("(?i)\\s+(feat|ft)\\.?\\s.*$"), "").replace(Regex("\\s+-\\s+.*$"), "").trim()

    private fun cleanArtist(a: String): String =
        a.split(Regex("(?i)\\s*(,|&|feat\\.?|ft\\.?|x)\\s+"))[0].trim()

    // Тексты песен ищем в приложении (lrclib.net, запасной вариант lyrics.ovh), без перехода в браузер
    private fun fetchLyricsAsync(key: String, artist: String, title: String, durSec: Int) {
        Thread {
            var plain = ""
            var synced = ""
            try {
                val ct = cleanTitle(title)
                val ca = cleanArtist(artist)
                val tries = listOf(Pair(artist, title), Pair(ca, ct)).distinct()
                for (pr in tries) {
                    if (plain.isNotEmpty() || synced.isNotEmpty()) break
                    val body = httpGetText(
                        "https://lrclib.net/api/get?artist_name=" + URLEncoder.encode(pr.first, "UTF-8") +
                            "&track_name=" + URLEncoder.encode(pr.second, "UTF-8") +
                            (if (durSec > 0) "&duration=$durSec" else "")
                    )
                    if (body != null) {
                        val o = JSONObject(body)
                        plain = jstr(o, "plainLyrics")
                        synced = jstr(o, "syncedLyrics")
                    }
                }
                if (plain.isEmpty() && synced.isEmpty()) {
                    val body = httpGetText("https://lrclib.net/api/search?q=" + URLEncoder.encode((ca + " " + ct).trim(), "UTF-8"))
                    if (body != null) {
                        val arr = JSONArray(body)
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            val p = jstr(o, "plainLyrics")
                            val sy = jstr(o, "syncedLyrics")
                            if (p.isNotEmpty() || sy.isNotEmpty()) {
                                plain = p
                                synced = sy
                                break
                            }
                        }
                    }
                }
                if (plain.isEmpty() && synced.isEmpty() && ca.isNotEmpty() && ct.isNotEmpty()) {
                    val body = httpGetText("https://api.lyrics.ovh/v1/" + URLEncoder.encode(ca, "UTF-8").replace("+", "%20") + "/" + URLEncoder.encode(ct, "UTF-8").replace("+", "%20"))
                    if (body != null) plain = jstr(JSONObject(body), "lyrics")
                }
            } catch (e: Exception) {
            }
            val res = JSONObject()
            res.put("p", plain)
            res.put("s", synced)
            runOnUiThread {
                web?.evaluateJavascript("window.onNativeLyrics&&window.onNativeLyrics(" + JSONObject.quote(key) + "," + JSONObject.quote(res.toString()) + ")", null)
            }
        }.start()
    }

    // Состояние батареи и сети для панели на главном экране
    @Suppress("DEPRECATION")
    private fun buildDeviceState(): String {
        val o = JSONObject()
        try {
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (bi != null) {
                val lvl = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val sc = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                o.put("level", if (lvl >= 0 && sc > 0) lvl * 100 / sc else -1)
                val st = bi.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                o.put("charging", st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL)
                o.put("full", st == BatteryManager.BATTERY_STATUS_FULL)
                o.put("plugged", bi.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0))
            }
            val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            o.put("curNow", bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
            o.put("chargeCounter", bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER))
            if (Build.VERSION.SDK_INT >= 28) o.put("chargeMs", bm.computeChargeTimeRemaining())
            if (Build.VERSION.SDK_INT >= 33) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                val d = pm.batteryDischargePrediction
                o.put("sysLeftMs", if (d != null) d.toMillis() else -1L)
            }
        } catch (e: Exception) {
        }
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val net = cm.activeNetwork
            val caps = if (net != null) cm.getNetworkCapabilities(net) else null
            var type = "none"
            if (caps != null) {
                type = when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cell"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "eth"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "vpn"
                    else -> "other"
                }
                o.put("validated", caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))
                o.put("down", caps.linkDownstreamBandwidthKbps)
            }
            o.put("net", type)
            if (type == "wifi") {
                try {
                    val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                    o.put("wifi", WifiManager.calculateSignalLevel(wm.connectionInfo.rssi, 5))
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
        }
        return o.toString()
    }

    private fun sendMediaKey(code: Int) {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        } catch (e: Exception) {
        }
    }

    private fun mediaControl(kind: Int) {
        val c = activeController()
        if (c == null) {
            if (kind == 0) sendMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            else if (kind == 1) sendMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
            else sendMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            return
        }
        val tc = c.transportControls
        if (kind == 0) {
            if (c.playbackState?.state == PlaybackState.STATE_PLAYING) tc.pause() else tc.play()
        } else if (kind == 1) {
            tc.skipToNext()
        } else {
            tc.skipToPrevious()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(5, 5, 5)))
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        val view = WebView(this)
        web = view
        view.setBackgroundColor(Color.rgb(5, 5, 5))
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.cacheMode = WebSettings.LOAD_DEFAULT
        view.settings.mediaPlaybackRequiresUserGesture = false
        view.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        view.overScrollMode = View.OVER_SCROLL_NEVER
        view.isVerticalScrollBarEnabled = false
        view.isHorizontalScrollBarEnabled = false
        view.settings.setSupportZoom(false)
        view.settings.builtInZoomControls = false
        view.settings.displayZoomControls = false
        view.addJavascriptInterface(Bridge(), "AndroidBridge")
        view.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) {
                pushInsets()
            }
        }
        view.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                filePathCb?.onReceiveValue(null)
                filePathCb = filePathCallback
                return try {
                    startActivityForResult(fileChooserParams!!.createIntent(), 21)
                    true
                } catch (e: Exception) {
                    filePathCb = null
                    false
                }
            }
        }
        view.setOnApplyWindowInsetsListener { v, insets ->
            val density = v.resources.displayMetrics.density
            var top = 0
            var bottom = 0
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                val ime = insets.getInsets(WindowInsets.Type.ime())
                top = bars.top
                bottom = Math.max(bars.bottom, ime.bottom)
            } else {
                top = insets.systemWindowInsetTop
                bottom = insets.systemWindowInsetBottom
            }
            safeTop = top / density
            safeBottom = bottom / density
            pushInsets()
            insets
        }
        view.loadUrl("file:///android_asset/index.html")
        setContentView(view)
        view.requestApplyInsets()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 21) {
            filePathCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            filePathCb = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onBackPressed() {
        val w = web
        if (w == null) {
            finish()
            return
        }
        w.evaluateJavascript("(window.nativeBack?window.nativeBack():false)") { r ->
            if (r != "true") finish()
        }
    }
}
