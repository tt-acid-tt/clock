# NEURO CLOCK Android

Проект собирается через GitHub Actions (см. .github/workflows/build-apk.yml в корне репозитория).
Интерфейс лежит в app/src/main/assets/index.html, оболочка Android — MainActivity.kt.
