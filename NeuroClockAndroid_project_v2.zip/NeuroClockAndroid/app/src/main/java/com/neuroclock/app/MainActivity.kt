package com.neuroclock.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowInsets
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private var web: WebView? = null
    private var safeTop = 0f
    private var safeBottom = 0f
    private var filePathCb: ValueCallback<Array<Uri>>? = null
    private val handler = Handler(Looper.getMainLooper())

    private fun pushInsets() {
        val w = web ?: return
        val js = "document.documentElement.style.setProperty('--safe-top','" + safeTop +
            "px');document.documentElement.style.setProperty('--safe-bottom','" + safeBottom + "px');"
        w.evaluateJavascript(js, null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun requestLocation() {
            runOnUiThread { startLocation() }
        }
    }

    private fun sendLoc(l: Location) {
        web?.evaluateJavascript(
            "window.onNativeLocation&&window.onNativeLocation(" + l.latitude + "," + l.longitude + ")", null
        )
    }

    private fun sendLocError(code: String) {
        web?.evaluateJavascript("window.onNativeLocationError&&window.onNativeLocationError('" + code + "')", null)
    }

    private fun hasLocationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < 23) return true
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun startLocation() {
        if (!hasLocationPermission()) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                31
            )
            return
        }
        fetchLocation()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 31) {
            var ok = false
            for (g in grantResults) {
                if (g == PackageManager.PERMISSION_GRANTED) ok = true
            }
            if (ok) fetchLocation() else sendLocError("denied")
        }
    }

    @SuppressLint("MissingPermission")
    private fun fetchLocation() {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = lm.getProviders(true)
        if (providers.isEmpty()) {
            sendLocError("disabled")
            return
        }
        var best: Location? = null
        for (prov in providers) {
            val l: Location? = try {
                lm.getLastKnownLocation(prov)
            } catch (e: Exception) {
                null
            }
            if (l != null) {
                val b = best
                if (b == null || l.accuracy < b.accuracy) best = l
            }
        }
        val found = best
        if (found != null) {
            sendLoc(found)
            return
        }
        val prov = if (providers.contains(LocationManager.NETWORK_PROVIDER)) LocationManager.NETWORK_PROVIDER else providers[0]
        var done = false
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (!done) {
                    done = true
                    lm.removeUpdates(this)
                    sendLoc(location)
                }
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        try {
            lm.requestLocationUpdates(prov, 0L, 0f, listener, Looper.getMainLooper())
        } catch (e: Exception) {
            sendLocError("disabled")
            return
        }
        handler.postDelayed({
            if (!done) {
                done = true
                lm.removeUpdates(listener)
                sendLocError("timeout")
            }
        }, 15000)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(5, 5, 5)))
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        val view = WebView(this)
        web = view
        view.setBackgroundColor(Color.rgb(5, 5, 5))
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.cacheMode = WebSettings.LOAD_DEFAULT
        view.settings.mediaPlaybackRequiresUserGesture = false
        view.addJavascriptInterface(Bridge(), "AndroidBridge")
        view.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) {
                pushInsets()
            }
        }
        view.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                filePathCb?.onReceiveValue(null)
                filePathCb = filePathCallback
                return try {
                    startActivityForResult(fileChooserParams!!.createIntent(), 21)
                    true
                } catch (e: Exception) {
                    filePathCb = null
                    false
                }
            }
        }
        view.setOnApplyWindowInsetsListener { v, insets ->
            val density = v.resources.displayMetrics.density
            var top = 0
            var bottom = 0
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                val ime = insets.getInsets(WindowInsets.Type.ime())
                top = bars.top
                bottom = Math.max(bars.bottom, ime.bottom)
            } else {
                top = insets.systemWindowInsetTop
                bottom = insets.systemWindowInsetBottom
            }
            safeTop = top / density
            safeBottom = bottom / density
            pushInsets()
            insets
        }
        view.loadUrl("file:///android_asset/index.html")
        setContentView(view)
        view.requestApplyInsets()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 21) {
            filePathCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            filePathCb = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onBackPressed() {
        val w = web
        if (w == null) {
            finish()
            return
        }
        w.evaluateJavascript("(window.nativeBack?window.nativeBack():false)") { r ->
            if (r != "true") finish()
        }
    }
}
