package com.neuroclock.app

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.view.WindowInsets
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private var web: WebView? = null
    private var safeTop = 0f
    private var safeBottom = 0f

    private fun pushInsets() {
        val w = web ?: return
        val js = "document.documentElement.style.setProperty('--safe-top','" + safeTop +
            "px');document.documentElement.style.setProperty('--safe-bottom','" + safeBottom + "px');"
        w.evaluateJavascript(js, null)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(5, 5, 5)))
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        val view = WebView(this)
        web = view
        view.setBackgroundColor(Color.rgb(5, 5, 5))
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
        view.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) {
                pushInsets()
            }
        }
        view.webChromeClient = WebChromeClient()
        view.setOnApplyWindowInsetsListener { v, insets ->
            val density = v.resources.displayMetrics.density
            var top = 0
            var bottom = 0
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                val ime = insets.getInsets(WindowInsets.Type.ime())
                top = bars.top
                bottom = Math.max(bars.bottom, ime.bottom)
            } else {
                top = insets.systemWindowInsetTop
                bottom = insets.systemWindowInsetBottom
            }
            safeTop = top / density
            safeBottom = bottom / density
            pushInsets()
            insets
        }
        view.loadUrl("file:///android_asset/index.html")
        setContentView(view)
        view.requestApplyInsets()
    }
}
